public class Square
{
}
