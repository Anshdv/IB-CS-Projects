package battery;

/**
 * TODO: Write class-level Javadoc here.
 *
 * Explain what a PhoneBattery is and what it models.
 * Add your name.
 */
public class PhoneBattery
{
    // TODO: declare your instance variables here.
    //
    //       Before you write anything, finish DESIGN.md.
    //       Ask yourself: what does this object need to remember
    //       so that it can carry out ALL SIX of its public members?
    //
    //       A full battery lasts 400 minutes.
    //       Every instance variable must be private.
    //       Do not store a value you could calculate.


    /**
     * TODO: Javadoc for the constructor.
     */
    public PhoneBattery()
    {
        // TODO: a new battery starts completely full.
    }


    /**
     * TODO: Javadoc. Remember @param.
     */
    public void use(int minutes)
    {
        // TODO
    }


    /**
     * TODO: Javadoc. Remember @param.
     */
    public void charge(int minutes)
    {
        // TODO
    }


    /**
     * TODO: Javadoc. Remember @return.
     */
    public int getMinutesRemaining()
    {
        return 0;   // TODO: replace this
    }


    /**
     * TODO: Javadoc. Remember @return.
     */
    public int getMinutesUsed()
    {
        // Minutes remaining and minutes used always add up to 400.
        return 0;   // TODO: replace this
    }


    /**
     * TODO: Javadoc. Remember @return.
     */
    public double getPercentRemaining()
    {
        // Every minute of battery is worth 0.25 percent.
        // You do not need to divide - multiply instead.
        return 0.0;   // TODO: replace this
    }
}
